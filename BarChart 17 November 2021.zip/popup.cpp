#include "popup.h"
#include <QVBoxLayout>
#include <QStandardItem>
#include <QHeaderView>

Popup::Popup(QWidget *parent) : QWidget(parent){
    setWindowFlags(Qt::FramelessWindowHint | Qt::SubWindow);
    setPalette(Qt::darkGray);
    auto lay = new QVBoxLayout(this);
    setLayout(lay);
    table = new QTableView(this);
    model = new QStandardItemModel(table);
    model->setColumnCount(3);
    table->setModel(model);
    table->horizontalHeader()->hide();
    table->verticalHeader()->hide();
    table->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);
    lay->addWidget(table);
    setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);
}
void Popup::setData(BarSeries &s){
    model->clear();
    auto name = new QStandardItem(s.name);
    auto val1 = new QStandardItem(QString::number(s.value1));
    auto val2 = new QStandardItem(QString::number(s.value2));
    model->appendRow(QList<QStandardItem*>() << name << val1 << val2);
    table->resizeRowsToContents();
    table->resizeColumnsToContents();
    table->adjustSize();
    adjustSize();
}
