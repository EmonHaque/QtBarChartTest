#ifndef AXIS_H
#define AXIS_H

#include <QGraphicsItem>

class Axis : public QGraphicsItem
{
public:
    Axis(QRectF rect, float max, int labelHeight, QGraphicsItem *parent = 0);
    QRectF boundingRect() const override;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr) override;

private:
    QRectF m_rect;
    float m_max;
    int m_labelHeight;
};

#endif // AXIS_H
