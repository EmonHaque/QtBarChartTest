#ifndef BARSERIES_H
#define BARSERIES_H
#include <QString>

struct BarSeries{
    QString name;
    float value1;
    float value2;
    BarSeries(const QString& name, float value1, float value2){
        this->name = name;
        this->value1 = value1;
        this->value2 = value2;
    }
};

#endif // BARSERIES_H
