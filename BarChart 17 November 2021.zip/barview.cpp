#include "barview.h"
#include "bar.h"
#include "axis.h"
#include <QFontMetrics>
#include <QGraphicsScene>
#include "popup.h"

BarView::BarView(QWidget *parent) : QGraphicsView(parent), m_spacing(5){
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    auto scene = new QGraphicsScene(this);
    scene->setSceneRect(0,0,200,200);
    setScene(scene);
    popup = new Popup();
    connect(this, &BarView::showPopup, this, &BarView::onShowPopup);
    connect(this, &BarView::closePopup, this, [=]{ popup->close(); });
}
void BarView::fit(){
    fitInView(scene()->itemsBoundingRect());
    centerOn(0,0);
}
void BarView::resizeEvent(QResizeEvent*){ fit(); }
void BarView::onShowPopup(BarSeries &s, QPointF p){
    popup->setGeometry(p.x() + 10, p.y() + 10, 0, 0);
    popup->setData(s);
    popup->show();
}
void BarView::addBars(QVector<BarSeries>& series){
    scene()->clear();
    float max = 0, total;
    QFontMetrics fm(font());
    int axisLabelWidth = 0, axisLabelHeight = 0, labelWidth = 0, labelHeight = 0;
    for (int i = 0; i < series.size(); i++) {
        total = series[i].value1 + series[i].value2;
        auto rect = fm.boundingRect(series[i].name);
        if(rect.width() > labelWidth) labelWidth = rect.width();
        if(rect.height() > labelHeight) labelHeight = rect.height();
        if(max < total) {
            max = total;
            auto rect = fm.boundingRect(QString::number(max));
            axisLabelWidth = rect.width();
            axisLabelHeight = rect.height();
        }
    }
    axisLabelWidth += 5;
    axisLabelHeight += 5;
    auto rect = sceneRect();
    auto axis = new Axis(QRectF(rect.left(), rect.top(), rect.width(), rect.height() - labelHeight), max, axisLabelHeight);
    scene()->addItem(axis);
    auto barWidth = (rect.width() - axisLabelWidth - (series.size() * m_spacing) - m_spacing) / series.size();
    float start = axisLabelWidth;
    for (int i = 0; i < series.size(); i++) {
        auto barRect = QRectF(start, rect.top(), barWidth, rect.height());
        auto bar = new Bar(barRect, series[i], max, axisLabelHeight, labelHeight);
        scene()->addItem(bar);
        start += m_spacing + barWidth;
    }
    fit();
}

