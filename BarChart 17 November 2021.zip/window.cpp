#include "window.h"
#include "BarSeries.h"
#include "barview.h"
#include <QVBoxLayout>
#include <QComboBox>

Window::Window(QWidget *parent) : QWidget(parent){
    setMinimumSize(400,400);
    auto lay = new QVBoxLayout(this);
    setLayout(lay);
    auto combo = new QComboBox(this);
    combo->addItems(QStringList() << "4" << "5");
    barChart = new BarView(this);
    barChart->setFrameShape(QFrame::Box);
    lay->addWidget(combo);
    lay->addWidget(barChart);
    connect(combo, &QComboBox::currentIndexChanged, this, &Window::onSelectionChanged);
    combo->setCurrentIndex(1);

}
Window::~Window(){}
void Window::onSelectionChanged(int index){
    QVector<BarSeries> series;
    series.append(BarSeries("S1", 100, 100));
    series.append(BarSeries("S2", 200, 100));
    series.append(BarSeries("S3", 300, 100));
    series.append(BarSeries("S4", 200, 0));
    if(index == 1) series.append(BarSeries("S5", 300, 200));
    barChart->addBars(series);
}

