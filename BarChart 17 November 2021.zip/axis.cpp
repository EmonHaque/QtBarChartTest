#include "axis.h"
#include <QPainter>
#include <QFontMetrics>

Axis::Axis(QRectF rect, float max, int labelHeight, QGraphicsItem *parent)
    : QGraphicsItem(parent), m_rect(rect), m_max(max), m_labelHeight(labelHeight) { }
QRectF Axis::boundingRect() const { return m_rect; }
void Axis::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *){
    painter->setRenderHints(QPainter::Antialiasing);
    painter->setPen(QPen(Qt::gray, 1, Qt::DashLine));
    painter->translate(0, m_rect.height());
    painter->scale(1, -1);
    int step = 5;
    float space = (m_rect.height() - m_labelHeight) / step;
    float increment = m_max / step;
    float start = 0, numStart = 0;
    QFontMetrics fm(painter->font());
    for(int i = 0; i < 6; i++){
        painter->drawLine(0, start, m_rect.width(), start);
        painter->save();
        auto label = QString::number(roundf(numStart));
        painter->scale(1, -1);
        //painter->translate(0, fm.boundingRect(label).height());
        painter->drawText(QPointF(0, -m_rect.height() + (step - i) * space + fm.boundingRect(label).height()), label);
        painter->restore();
        start += space;
        numStart += increment;
    }
}


