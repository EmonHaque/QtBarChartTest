#ifndef BAR_H
#define BAR_H

#include <QGraphicsItem>
#include "BarSeries.h"

class Bar : public QGraphicsItem
{
public:
    Bar(QRectF rect, BarSeries& s, float max, int axisLabelHeight, int labelHeight, QGraphicsItem * parent = 0);
    QRectF boundingRect() const;
    QPainterPath shape() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
protected:
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event);
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);
private:
    QRectF m_rect, m_rect1, m_rect2;
    QPainterPath m_shape;
    BarSeries m_series;
    QColor m_topColor, m_bottomColor;
    float m_max, h1, h2;
    int m_axisLabelHeight, m_labelHeight, m_barHeight;
};

#endif // BAR_H
