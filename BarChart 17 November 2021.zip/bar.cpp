#include "bar.h"
#include <QPainter>
#include <QGraphicsRectItem>
#include <QPainterPath>
#include <QGraphicsSceneHoverEvent>
#include "barview.h"

Bar::Bar(QRectF rect, BarSeries& s, float max, int axisLabelHeight, int labelHeight, QGraphicsItem *parent)
    : QGraphicsItem(parent), m_rect(rect), m_series(s), m_max(max),
      m_axisLabelHeight(axisLabelHeight), m_labelHeight(labelHeight){
    m_topColor = Qt::gray;
    m_bottomColor = Qt::black;
    h1 = m_series.value1 / m_max * (m_rect.height() - m_axisLabelHeight - m_labelHeight);
    h2 = m_series.value2 / m_max * (m_rect.height() - m_axisLabelHeight - m_labelHeight);
    m_barHeight = h1 + h2;
    m_rect1 = QRectF(m_rect.left(), m_labelHeight, m_rect.width(), h1);
    m_rect2 = QRectF(m_rect.left(), m_labelHeight + h1, m_rect.width(), h2);
    setAcceptHoverEvents(true);
}
QRectF Bar::boundingRect() const { return m_rect; }
QPainterPath Bar::shape() const{
    QPainterPath path;
    path.addRect(m_rect.left(), m_rect.height() - m_labelHeight - m_barHeight, m_rect.width(), m_barHeight);
    return path;
}
void Bar::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *){
    painter->setRenderHints(QPainter::Antialiasing);
    painter->setPen(Qt::NoPen);
    painter->translate(0, m_rect.height());
    painter->scale(1.0, -1.0);
    painter->setBrush(m_bottomColor);
    painter->drawRect(m_rect1);
    painter->setBrush(m_topColor);
    painter->drawRect(m_rect2);
    painter->setPen(Qt::gray);
    painter->scale(1, -1);
    //painter->rotate(-15);
    painter->drawText(m_rect.left(), 0, m_series.name);
}
void Bar::hoverEnterEvent(QGraphicsSceneHoverEvent *e){
    m_topColor = Qt::darkGreen;
    m_bottomColor = Qt::darkRed;
    update();
    auto view = qobject_cast<BarView*>(scene()->parent());
    emit view->showPopup(m_series, e->screenPos());
}
void Bar::hoverLeaveEvent(QGraphicsSceneHoverEvent*){
    m_topColor = Qt::gray;
    m_bottomColor = Qt::black;
    update();
    auto view = qobject_cast<BarView*>(scene()->parent());
    emit view->closePopup();
}
