#ifndef WINDOW_H
#define WINDOW_H

#include <QWidget>

class BarView;
class Window : public QWidget
{
    Q_OBJECT

public:
    Window(QWidget *parent = nullptr);
    ~Window();
private slots:
    void onSelectionChanged(int index);
private:
    BarView *barChart;
};
#endif // WINDOW_H
