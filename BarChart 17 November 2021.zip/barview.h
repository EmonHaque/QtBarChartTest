#ifndef BARVIEW_H
#define BARVIEW_H

#include <QGraphicsView>
#include <QObject>
#include <QWidget>
#include "BarSeries.h"
class Popup;
class BarView : public QGraphicsView
{
    Q_OBJECT
public:
    BarView(QWidget * parent = 0);
    void addBars(QVector<BarSeries> &series);
protected:
    void resizeEvent(QResizeEvent *event);
signals:
    void showPopup(BarSeries&, QPointF);
    void closePopup();
private slots:
    void onShowPopup(BarSeries&, QPointF);
private:
    float m_spacing;
    void fit();
    Popup * popup;

};

#endif // BARVIEW_H
