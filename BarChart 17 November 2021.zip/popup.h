#ifndef POPUP_H
#define POPUP_H

#include <QObject>
#include <QWidget>
#include <QTableView>
#include <QStandardItemModel>
#include "BarSeries.h"

class Popup : public QWidget
{
    Q_OBJECT
public:
    explicit Popup(QWidget *parent = nullptr);
    void setData(BarSeries&);
private:
    QTableView *table;
    QStandardItemModel *model;
};

#endif // POPUP_H
